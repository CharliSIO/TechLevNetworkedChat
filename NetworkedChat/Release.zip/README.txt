Commands:
/CAPITALISE message
/SET secret
/GET
/WHISPER 
 - the command for whisper should be followed by a space, and the first character of the whispered message is the ID of the target client to receive the private message
		example: /WHISPER 2Private message to client with ID 2!
/QUIT

C++ 11 Features
Lambas used during iteration in find/transform algorithms in Server::GetCommand
Conditional variable used in thread-safe queue to wait on availability to access message within server messageBuffer
Atomic variables used for checking if should close the program
Variadic template allows thread-safe queue to be used for not just message but other template types 

Note: the server IP find does not return correct address, address is not 0.0.0.0